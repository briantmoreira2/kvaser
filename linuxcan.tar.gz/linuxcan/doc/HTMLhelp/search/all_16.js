var searchData=
[
  ['xml_5ferror_5fmessage_5flength',['XML_ERROR_MESSAGE_LENGTH',['../kva_memo_lib_x_m_l_8h.html#af101e30719b94a31bfca04d5089dfc0d',1,'kvaMemoLibXML.h']]]
];
