var searchData=
[
  ['file_20handling',['File Handling',['../group__grp__kvfile.html',1,'']]],
  ['file_20operations',['File Operations',['../group__kvm__files.html',1,'']]]
];
