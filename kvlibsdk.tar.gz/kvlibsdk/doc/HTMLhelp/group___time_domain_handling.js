var group___time_domain_handling =
[
    [ "kvTimeDomainAddHandle", "group___time_domain_handling.html#ga73890ef75367c8536235bcc5a6370b26", null ],
    [ "kvTimeDomainCreate", "group___time_domain_handling.html#gaef2b34a7cd8ab01fc140aabe3a5f5539", null ],
    [ "kvTimeDomainDelete", "group___time_domain_handling.html#gaf42198d9685ffc7094fc4cd276ab1976", null ],
    [ "kvTimeDomainGetData", "group___time_domain_handling.html#gafab02cbe0c7fd8cfa65382d492d724b9", null ],
    [ "kvTimeDomainRemoveHandle", "group___time_domain_handling.html#gad9f730b78a8755e4ec915f75d47e2c79", null ],
    [ "kvTimeDomainResetTime", "group___time_domain_handling.html#gaf1857d6195e783c082b44a6e6cf9f745", null ]
];