var searchData=
[
  ['real_20time_20clock',['Real Time Clock',['../group__kvm__rtc.html',1,'']]],
  ['receive_20and_20reply_20to_20can_20message',['Receive and reply to CAN message',['../page_example_c_echo.html',1,'page_user_guide_canlib_samples']]],
  ['remote_20device_20api_20_28kvrlib_29',['Remote Device API (kvrlib)',['../page_kvrlib.html',1,'']]],
  ['raw',['raw',['../structkvm_log_event_ex.html#a2d78703fd9a85a4cb3ead816db9038bc',1,'kvmLogEventEx']]],
  ['right',['right',['../structtag__token.html#afa54f74105f850a372148e16dde90651',1,'tag_token']]],
  ['ro1',['RO1',['../structkv_io_module_relay.html#a51f47034125d484b8a7d13e414f2854a',1,'kvIoModuleRelay']]],
  ['ro2',['RO2',['../structkv_io_module_relay.html#a74ec56c96381bdbac5979ca55f1f6c81',1,'kvIoModuleRelay']]],
  ['ro3',['RO3',['../structkv_io_module_relay.html#a5b25e1ffac3bdd23e1b7be606abfd437',1,'kvIoModuleRelay']]],
  ['ro4',['RO4',['../structkv_io_module_relay.html#ab3f579cac16905edf55011dcc2e9090a',1,'kvIoModuleRelay']]],
  ['ro5',['RO5',['../structkv_io_module_relay.html#a2a2866e10a2945ebd13e09bcbb57cd52',1,'kvIoModuleRelay']]],
  ['ro6',['RO6',['../structkv_io_module_relay.html#ac8627cecb81615ec17028f05c2faf449',1,'kvIoModuleRelay']]],
  ['ro7',['RO7',['../structkv_io_module_relay.html#a459a1901794b9ff25b154c25696a14c4',1,'kvIoModuleRelay']]],
  ['ro8',['RO8',['../structkv_io_module_relay.html#a9fcce63e7449e5adb9ae98deaaf5efee',1,'kvIoModuleRelay']]],
  ['rtc',['rtc',['../structkvm_log_event_ex.html#a1f9964cb31c1515adcee1dc69c01d41b',1,'kvmLogEventEx']]],
  ['rx',['rx',['../structcan_notify_data.html#a08ba82dcb2d1828a60a16863d4266189',1,'canNotifyData']]],
  ['rxerrorcounter',['rxErrorCounter',['../structcan_notify_data.html#a575e147dffea7d8a2fc90141079a4fe3',1,'canNotifyData']]]
];
