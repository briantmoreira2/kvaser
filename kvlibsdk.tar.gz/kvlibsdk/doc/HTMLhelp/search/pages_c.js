var searchData=
[
  ['plain_20text_20_28r_2fw_29',['Plain text (R/W)',['../kvlclib_format__p_l_a_i_n__a_s_c.html',1,'kvlclib_formats']]],
  ['properties',['Properties',['../kvlclib_properties.html',1,'page_kvlclib']]]
];
